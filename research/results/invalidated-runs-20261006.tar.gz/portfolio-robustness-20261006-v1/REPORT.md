# Invalidated intermediate run

Production risk source changed while this experiment was running. All 37 completed trial records and traces remain retained. They are not final-source results.

All84 predeclared trials are rerun under portfolio-robustness-20261006-v2 with unchanged plan and data.
